from website import create_app, apis
import os
app = create_app()
app.run(debug=False, port=800, host='0.0.0.0')